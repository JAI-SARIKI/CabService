package dto.response;

public class CheckStatusResponse {
}
