package dto.response;

public class BookingResponse {
}
