package dto.response;

public class AvailabilityResponse {
}
