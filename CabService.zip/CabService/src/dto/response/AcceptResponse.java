package dto.response;

public class AcceptResponse {
}
