package dto.response;

public class NewRidesCheckResponse {
}
