package dto.reuqest;

public class AvailabilityRequest {
}
