package dto.reuqest;

public class CheckStatusRequest {
}
