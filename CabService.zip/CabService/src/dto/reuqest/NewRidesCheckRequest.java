package dto.reuqest;

public class NewRidesCheckRequest {
}
