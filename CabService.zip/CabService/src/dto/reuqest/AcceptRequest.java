package dto.reuqest;

public class AcceptRequest {
}
