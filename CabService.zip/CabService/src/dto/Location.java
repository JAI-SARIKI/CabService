package dto;

public class Location {
    private int latitude;
    private int longitude;
}
