package db;

public class BookingDetailsRepository {
    private BookingDetailsRepository bookingDetailsRepository;
    BookingDetailsRepository() {
        if(bookingDetailsRepository==null) {
            bookingDetailsRepository = new BookingDetailsRepository();
        }
    }

    public BookingDetailsRepository getBookingDetailsRepository() {
        return bookingDetailsRepository;
    }



}
