package db;

public class RiderRepository {
}
