package constatnt;

public enum BookingStatus {
    PENDING,
    ACCEPTED,
    COMPLETED,
    CANCELLED;
}
