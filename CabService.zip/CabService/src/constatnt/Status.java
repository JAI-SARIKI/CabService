package constatnt;

public enum Status {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED;
}
