package service;

public class BookingService {
}
