package service;

import entities.Driver;

import java.awt.dnd.DragGestureRecognizer;

public class OnboardingService {
    public void onboardDriver(Driver driver) {

    }
}
